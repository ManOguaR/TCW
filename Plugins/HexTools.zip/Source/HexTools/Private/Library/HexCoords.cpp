// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 


#include "HexCoords.h"

OffsetCoord::OffsetCoord(int col, int row) : Col(col), Row(row) {}

OffsetCoord::~OffsetCoord()
{
}

DoubledCoord::DoubledCoord(int col, int row) : Col(col), Row(row) {}

DoubledCoord::~DoubledCoord()
{
}
