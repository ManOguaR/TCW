// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 

#pragma once

#include "CoreMinimal.h"

#include "HexCoords.h"
#include "IHex.h"

/**
 *
 */
class HEXTOOLS_API Hex : public IHex
{
protected:
	/// <summary>Construct a new Hex instance at location <paramref name="coords"/>.</summary>
	Hex(HexCoords coords);
	/// <summary>Construct a new Hex instance at location <paramref name="coords"/>.</summary>
	Hex(HexCoords coords, int elevationLevel);

public:
	virtual ~Hex();

#pragma region IHex Interface
	/// <summary>The <c>HexCoords</c> coordinates for this hex on <c>Board</c>.</summary>
	HexCoords GetCoords() override;

	/// <summary>Elevation of this hex in "steps" above the minimum elevation of the board.</summary>
	int GetElevationLevel() override;

	/// <summary>Height ASL in <i>game units</i> of observer's eyes for FOV calculations.</summary>
	virtual int GetHeightObserver() override;

	/// <summary>Height ASL in <i>game units</i> of target above ground level to be spotted.</summary>
	virtual int GetHeightTarget() override;

	/// <summary>Height ASL in <i>game units</i> of any blocking terrian in this hex.</summary>
	virtual int GetHeightTerrain() override = 0;

	/// <summary>Char code for the tYpe of the terrain in this hex.</summary>
	virtual char GetTerrainType() override = 0;

	/// <summary>Returns true exactly when thhis hex is passable.</summary>
	virtual bool GetIsPassable() override = 0;

	/// <summary>Cost to extend the path with the hex located across the <c>Hexside</c> at <c>direction</c>.</summary>
	virtual int GetEntryCost(Hexside hexsideExit) override = 0;

	/// <summary>Cost to extend the path with the hex located across the <c>Hexside</c> at <c>direction</c>.</summary>
	virtual int GetExitCost(Hexside hexsideExit) override = 0;

	/// <summary>Height ASL in <i>game units</i> of any blocking terrain in this hex and the specified Hexside.</summary>
	virtual int GetHeightHexside(Hexside hexside) override;

#pragma endregion

private:
	HexCoords Coords;

	int ElevationLevel;

	int HeightObserver = 1;

	int HeightTarget = 1;

public:
	bool Equals(Hex& other);

};

/// <summary>Tests value-inequality.</summary>
static bool operator !=(Hex& lhs, Hex& rhs);

/// <summary>Tests value-equality.</summary>
static bool operator ==(Hex& lhs, Hex& rhs);

