// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 

#pragma once

#include "CoreMinimal.h"

/**
 * 
 */
class HEXTOOLS_API BlockedBoardStorage32x32
{
public:
	BlockedBoardStorage32x32();
	~BlockedBoardStorage32x32();
};
