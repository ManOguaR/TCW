// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 

#pragma once

#include "CoreMinimal.h"

/// <summary>A Maybe monad wrapping an instance of type <typeparamref name="T"/>.</summary>
template<class T>
class HEXTOOLS_API Maybe
{
public:
	static Maybe<T> NoValue();

public:
	Maybe();
	/// <summary>TODO</summary>
	Maybe(T value);
	~Maybe();

public:
	/// <summary>TODO</summary>
	bool HasValue() { return Value != NULL; };

private:
	T Value;

public:
	//TODO: FUNC<>
	/// <summary>TODO</summary>
	//template<class TOut>
	//Maybe<TOut> Bind(Func<T, Maybe<TOut>> projection);

	/// <summary>TODO</summary>
	//template<class TOut>
	//TOut Match(Func<T, TOut> projection, Func<TOut> alternate);

	/// <summary>TODO</summary>
	//bool ValueContract(Func<T, bool> contract);

private:
	static FString PreferredName(T value);

	static FString AlternateName();

public:
	/// <summary>TODO</summary>
	static Maybe<T> From(T value);

#pragma region Value Equality
public:
	/// <inheritdoc/>
	bool Equals(Maybe<T> other);
#pragma endregion

public:
	/// <summary>TODO</summary>
	FString ToString();

	//TODO: template<struct V>
	/// <summary>TODO</summary>
	//template<struct V>
	//static Maybe<V> ToMaybe(Maybe<V> maybe);

	/// <summary>TODO</summary>
	//template<struct V>
	//static V ToNullable(Maybe<V> maybe);

};

#pragma region Value Equality
/// <summary>Tests value-inequality.</summary>
template<class T>
static bool operator != (Maybe<T> lhs, Maybe<T> rhs) { return !lhs.Equals(rhs); };

/// <summary>Tests value-equality.</summary>
template<class T>
static bool operator == (Maybe<T> lhs, Maybe<T> rhs) { return lhs.Equals(rhs); };
#pragma endregion





