// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 

#pragma once

#include "CoreMinimal.h"

#include "IHexgrid.h"

/// <summary>C# implementation of the hex-picking algorithm noted below.</summary>
/// <remarks>Mathemagically (left as exercise for the reader) our 'picking' matrices are these, assuming: 
///  - origin at upper-left corner of hex (0,0);
///  - 'straight' hex-axis vertically down; and
///  - 'oblique'  hex-axis up-and-to-right (at 120 degrees from 'straight').</remarks>
/// <a href="file://Documentation/HexGridAlgorithm.mht">Hex-grid Algorithms</a>
class HEXTOOLS_API HexGrid : public IHexgrid
{
public:
	/// <summary>Return a new instance of <c>Hexgrid</c>.</summary>
	HexGrid(bool isTransposed, FVector2D gridSize, float scale);
	/// <summary>Return a new instance of <c>Hexgrid</c>.</summary>
	HexGrid(bool isTransposed, FVector2D gridSize, float scale, FVector2D margin);
	virtual ~HexGrid();

private:
	FVector2D _gridSize;
	TArray<FIntPoint> _hexCorners;
	bool _isTransposed;
	FVector2D _margin;
	float _scale;

public:
	/// <summary>TODO</summary>
	FVector2D GetGridSize() { return _gridSize; };
	/// <summary>TODO</summary>
	TArray<FIntPoint> GetHexCorners() { return _hexCorners; };
	/// <summary>TODO</summary>
	bool GetIsTransposed() { return _isTransposed; };
	/// <summary>Offset of grid origin, from control's client-area origin.</summary>
	FVector2D GetMargin() { return _margin; };
	void SetMargin(FVector2D value) { _margin =value; };
	/// <summary>TODO</summary>
	float GetScale() { return _scale; };
};
