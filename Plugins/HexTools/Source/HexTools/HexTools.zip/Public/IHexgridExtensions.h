// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 

#pragma once

#include "CoreMinimal.h"
#include "IHexgrid.h"
#include "HexCoords.h"
#include "UserCoordsRectangle.h"

/**
 *
 */
class HEXTOOLS_API IHexgridExtensions final
{
public:
	/// <summary>Returns the scroll position to center a specified hex in viewport.</summary>
	/// <param name="this"></param>
	/// <param name="coordsNewCenterHex"><c>HexCoords</c> for the hex to be centered in viewport.</param>
	/// <param name="visibleRectangle"></param>
	/// <returns>Pixel coordinates in Client reference frame.</returns>
	static FIntPoint ScrollPositionToCenterOnHex(const IHexgrid& hexGrid, HexCoords coordsNewCenterHex, CoordsRectangle visibleRectangle);

	/// <summary>TODO</summary>
	/// <param name="this"></param>
	/// <param name="mapSizePixels"></param>
	/// <param name="mapScale"></param>
	static FVector2D GetSize(const IHexgrid& hexGrid, FVector2D mapSizePixels, float mapScale);
};



