// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 

#pragma once

#include "CoreMinimal.h"

#include "HexCoords.h"
#include "IHex.h"
#include "Maybe.h"

/// <summary>The basic interface defining a mapboard with hexes.</summary>
template<class THex = IHex>
class HEXTOOLS_API IBoard
{
public:
	/// <summary>The rectangular extent of the board's hexagonal grid, in hexes.</summary>
	virtual FVector2D GetMapSizeHexes() = 0;

	/// <summary>Returns the <c>IHex</c> at location <c>coords</c>.</summary>
	virtual Maybe<THex> Get(HexCoords coords) = 0;

public:
	/// <summary>Returns whether the hex at location <c>coords</c>is "on board".</summary>
	virtual bool IsOnboard(HexCoords coords) = 0;

	//TODO: ACTION<>
	/// <summary>Perform <paramref name="action"/> for all neighbours of this hex.</summary>
	//virtual void ForAllNeighbours(HexCoords coords, Action<THex, Hexside> action) = 0;

};