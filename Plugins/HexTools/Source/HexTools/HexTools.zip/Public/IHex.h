// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 

#pragma once

#include "CoreMinimal.h"

#include "Hexside.h"

 /// <summary>External interface exposed by individual hexes.</summary>
class HEXTOOLS_API IHex
{
public:
	/// <summary>The <c>HexCoords</c> coordinates for this hex on <c>Board</c>.</summary>
	virtual HexCoords GetCoords() = 0;

	/// <summary>Elevation of this hex in "steps" above the minimum elevation of the board.</summary>
	virtual int GetElevationLevel() = 0;

	/// <summary>Height ASL in <i>game units</i> of observer's eyes for FOV calculations.</summary>
	virtual int GetHeightObserver() = 0;

	/// <summary>Height ASL in <i>game units</i> of target above ground level to be spotted.</summary>
	virtual int GetHeightTarget() = 0;

	/// <summary>Height ASL in <i>game units</i> of any blocking terrian in this hex.</summary>
	virtual int GetHeightTerrain() = 0;

	/// <summary>Char code for the tYpe of the terrain in this hex.</summary>
	virtual char GetTerrainType() = 0;

	/// <summary>Returns true exactly when thhis hex is passable.</summary>
	virtual bool GetIsPassable() = 0;

	/// <summary>Cost to extend the path with the hex located across the <c>Hexside</c> at <c>direction</c>.</summary>
	virtual int GetEntryCost(Hexside hexsideExit) = 0;

	/// <summary>Cost to extend the path with the hex located across the <c>Hexside</c> at <c>direction</c>.</summary>
	virtual int GetExitCost(Hexside hexsideExit) = 0;

	/// <summary>Height ASL in <i>game units</i> of any blocking terrain in this hex and the specified Hexside.</summary>
	virtual int GetHeightHexside(Hexside hexside) = 0;
};
