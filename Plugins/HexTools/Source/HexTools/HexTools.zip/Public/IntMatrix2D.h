// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 

#pragma once

#include "CoreMinimal.h"
#include "IntVector2D.h"

/**
 *
 */
class HEXTOOLS_API IntMatrix2D
{
#pragma region Constructors
public:
	/// <summary> Initializes a new <code>IntMatrix2D</code> as the translation defined by the vector vector.</summary>
	/// <param name="vector">the translation vector</param>
	IntMatrix2D(IntVector2D vector);

	/// <summary> Initializes a new <code>IntMatrix2D</code> as the translation (dx,dy).</summary>
	/// <param name="dx">X-translate component</param>
	/// <param name="dy">Y-translate component</param>
	IntMatrix2D(int dx, int dy);

	/// <summary> Initialies a new <code>IntMatrix2D</code> with a rotation.</summary>
	/// <param name="m11">X-scale component.</param>
	/// <param name="m12">Y-shear component</param>
	/// <param name="m21">X-shear component</param>
	/// <param name="m22">Y-scale component</param>
	IntMatrix2D(int m11, int m12, int m21, int m22);

	/// <summary>Initializes a new fully-specificed <code>IntMatrix2D</code> .</summary>
	/// <param name="m11">X-scale component.</param>
	/// <param name="m12">Y-shear component</param>
	/// <param name="m21">X-shear component</param>
	/// <param name="m22">Y-scale component</param>
	/// <param name="dx">X-translate component</param>
	/// <param name="dy">Y-translate component</param>
	IntMatrix2D(int m11, int m12, int m21, int m22, int dx, int dy);

	/// <summary>Initializes a new fully-specificed non-normed <code>IntMatrix2D</code>.</summary>
	/// <param name="m11">X-scale component.</param>
	/// <param name="m12">Y-shear component</param>
	/// <param name="m21">X-shear component</param>
	/// <param name="m22">Y-scale component</param>
	/// <param name="dx">X-translate component</param>
	/// <param name="dy">Y-translate component</param>
	/// <param name="norm">Normalization component</param>
	IntMatrix2D(int m11, int m12, int m21, int m22, int dx, int dy, int norm);

	~IntMatrix2D();
#pragma endregion

#pragma region Properties
private:
	int _m11, _m12, _m21, _m22, _m31, _m32, _m33;

public:
	/// <summary>Get the i-scale component.</summary>
	int GetM11() { return _m11; };
	/// <summary>Get the X-shear component</summary>
	int GetM12() { return _m12; };
	/// <summary>Get the j-shear component</summary>
	int GetM21() { return _m21; };
	/// <summary>Get the Y-scale component</summary>
	int GetM22() { return _m22; };
	/// <summary>Get the i-translation component</summary>
	int GetM31() { return _m31; };
	/// <summary>Get the j-translationcomponent</summary>
	int GetM32() { return _m32; };
	/// <summary>Ge the normalization component</summary>
	int GetM33() { return _m33; };

	/// <summary>Get the identity @this.</summary>
	static const IntMatrix2D Identity;

	/// <summary>todo</summary>
	int Determinant = ((_m11 * _m22) - (_m21 * _m12));
#pragma endregion

#pragma region Operators
public:
	/// <summary>(Contravariant) Vector transformation by a matrix.</summary>
	static IntVector2D Multiply(IntVector2D v, IntMatrix2D m);
	static IntVector2D Multiply(IntMatrix2D m, IntVector2D v);

	/// <summary>(Covariant) Vector transformation by a matrix.</summary>
	static IntMatrix2D Multiply(IntMatrix2D m1, IntMatrix2D m2);
#pragma endregion

};

#pragma region Operators
/// <summary>(Contravariant) Vector transformation by a matrix.</summary>
/// <param name="v">IntVector2D to be transformed.</param>
/// <param name="m">IntMatrix2D to be applied.</param>
/// <returns>New IntVector2D resulting from application of matrix <paramref name="m"/> to vector <paramref name="v"/>.</returns>
static IntVector2D operator * (IntVector2D v, IntMatrix2D m);

/// <summary>(Covariant) Vector transformation by a matrix.</summary>
/// <param name="m">IntMatrix2D to be applied.</param>
/// <param name="v">IntVector2D to be transformed.</param>
/// <returns>New IntVector2D resulting from application of matrix <paramref name="m"/> to vector <paramref name="v"/>.</returns>
//[Obsolete("The standard in PGNapoleonics is to use Contravariant (ie column) vectors.")]
static IntVector2D operator * (IntMatrix2D m, IntVector2D v);

/// <summary>Matrix multiplication.</summary>
/// <param name="m1">Prepended transformation.</param>
/// <param name="m2">Appended transformation.</param>
/// <returns></returns>
static IntMatrix2D operator * (IntMatrix2D m1, IntMatrix2D m2);
#pragma endregion


