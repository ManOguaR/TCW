// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 

#pragma once

#include "CoreMinimal.h"
#include "HexCoords.h"
#include "IHexgrid.h"

/**
 * 
 */
//class HEXTOOLS_API HexPickingExtensions final
//{
//public:
//    /// <summary>Scroll position on the (possibly transposed) HexGrid.</summary>
//    /// <param name="this"></param>
//    /// <param name="scrollPosition"></param>
//    static FIntPoint GetScrollPosition(IHexgrid& hexGrid, FIntPoint scrollPosition);
//
//    /// <summary>.</summary>
//    /// <param name="this"></param>
//    static FVector2D GridSizeF(IHexgrid& hexGrid);
//
//    /// <summary><c>HexCoords</c> for the hex at the screen point, with the given AutoScroll position.</summary>
//    /// <param name="this"></param>
//    /// <param name="point">Screen point specifying hex to be identified.</param>
//    /// <param name="autoScroll">AutoScrollPosition for game-display Panel.</param>
//    static HexCoords GetHexCoords(IHexgrid& hexGrid, FVector2D point, FVector2D autoScroll);
//
//    /// <summary><c>HexCoords</c> for the hex at the screen point, with the given AutoScroll position.</summary>
//    /// <param name="this"></param>
//    /// <param name="point">Screen point specifying hex to be identified.</param>
//    /// <param name="autoScroll">AutoScrollPosition for game-display Panel.</param>
//    static HexCoords GetHexCoords(IHexgrid& hexGrid, FIntPoint point, FVector2D autoScroll);
//
//    /// <summary><c>HexCoords</c> for the hex at the screen point, with the given AutoScroll position.</summary>
//    /// <param name="this"></param>
//    /// <param name="point">Screen point specifying hex to be identified.</param>
//    /// <param name="autoScroll">AutoScrollPosition for game-display Panel.</param>
//    static HexCoords GetHexCoordsInner(IHexgrid& hexGrid, FIntPoint point, FVector2D autoScroll);
//
//    /// <summary>Returns ScrollPosition that places given hex in the upper-Left of viewport.</summary>
//    /// <param name="this"></param>
//    /// <param name="coordsNewULHex"><c>HexCoords</c> for new upper-left hex</param>
//    /// <returns>Pixel coordinates in Client reference frame.</returns>
//    static FIntPoint HexCenterPoint(IHexgrid& hexGrid, HexCoords coordsNewULHex);
//
//    /// <summary>Returns ScrollPosition that places given hex in the upper-Left of viewport.</summary>
//    /// <param name="this"></param>
//    /// <param name="coordsNewULHex"><c>HexCoords</c> for new upper-left hex</param>
//    /// <returns>Pixel coordinates in Client reference frame.</returns>
//    static FIntPoint HexCenterPointInner(IHexgrid& hexGrid, HexCoords coordsNewULHex);
//
//    /// <summary>Returns the pixel coordinates of the center of the specified hex.</summary>
//    /// <param name="this"></param>
//    /// <param name="coords"><see cref="HexCoords"/> specification for which pixel center is desired.</param>
//    /// <returns>Pixel coordinates of the center of the specified hex.</returns>
//    static FIntPoint HexOrigin(IHexgrid& hexGrid, HexCoords coords);
//
//    /// <summary>Calculates a (canonical X or Y) grid-coordinate for a point, from the supplied 'picking' matrix.</summary>
//    /// <param name="this"></param>
//    /// <param name="matrix">The 'picking-matrix' matrix</param>
//    /// <param name="point">The screen point identifying the hex to be 'picked'.</param>
//    /// <returns>A (canonical X or Y) grid coordinate of the 'picked' hex.</returns>
//    static int GetCoordinate(IHexgrid& hexGrid, FMatrix matrix, FIntPoint point);
//
//    /// <summary>Calculates a (canonical X or Y) grid-coordinate for a point, from the supplied 'picking' matrix.</summary>
//    /// <param name="this"></param>
//    /// <param name="matrix">The 'picking-matrix' matrix</param>
//    /// <param name="point">The screen point identifying the hex to be 'picked'.</param>
//    /// <returns>A (canonical X or Y) grid coordinate of the 'picked' hex.</returns>
//    static int GetCoordinate(IHexgrid& hexGrid, FMatrix matrix, FVector2D point);
//
//    /// <summary><see cref="FMatrix"/> for 'picking' the <B>X</B> hex coordinate</summary>
//    static FMatrix MatrixX(IHexgrid& hexGrid);
//
//    /// <summary><see cref="FMatrix"/> for 'picking' the <B>Y</B> hex coordinate</summary>
//    static FMatrix MatrixY(IHexgrid& hexGrid);
//
//    static FIntPoint TransposePoint(FIntPoint point);
//
//    static FVector2D TransposeSize(FVector2D  size);
//
//};
