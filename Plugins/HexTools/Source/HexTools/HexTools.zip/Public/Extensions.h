// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 

#pragma once

#include "CoreMinimal.h"
#include "HexCoords.h"
#include "IHex.h"

/**
 * 
 */
class HEXTOOLS_API Extensions final
{
public:
    /// <summary><b>True</b>b> <i>modulo</i> operation returning <paramref name="dividend"/> mod <paramref name="divisor"/>.</summary>
    /// <param name="dividend"></param>
    /// <param name="divisor"></param>
    /// <returns></returns>
    static int Modulo(const int dividend, int divisor);

    /// <summary>Returns whether the specified hex coordinates are "on" a board of the given dimensions.</summary>
    /// <param name="mapSizeHexes">The hex dimensions of the board.</param>
    /// <param name="hexCoords">The hex coordinates of the hex of interest.</param>
    static bool IsOnboard(const FVector2D mapSizeHexes, HexCoords hexCoords);

    /// <summary>Returns whether the specified hex coordinates are "on" a board of the given dimensions.</summary>
    /// <param name="mapSizeHexes">The hex dimensions of the board.</param>
    /// <param name="userCoords">The User coordinates of the hex of interest.</param>
    static bool IsOnboard(const FVector2D mapSizeHexes, IntVector2D userCoords);

    /// <summary>Returns whether the specified hex coordinates are "on" a board of the given dimensions.</summary>
    /// <param name="mapSizeHexes">The hex dimensions of the board.</param>
    /// <param name="x">The horizontal hex index of the hex of interest.</param>
    /// <param name="y">The vertical hex index of the hex of interest.</param>
    static bool IsOnboard(const FVector2D mapSizeHexes, int x, int y);

    //TODO: Func<T>
    /// <summary>Create and initialize a non-local <see cref="IDisposable"/> instance safely.</summary>
    /// <typeparam name="T">The <see cref="IDisposable"/> type being initialized.</typeparam>
    /// <param name="initializer">The <i>functor</i> creating and initializing the instance.</param>
    /// <returns>Returns a safely initialized <see cref="IDisposable"/> instance</returns>
    /// <remarks>
    /// The returned <see cref="IDisposable"/> instance has been constructed and initialized in a manner
    /// that does not raise the warning: <b>CA2000:</b> <i>Dispose objects before losing scope</i>.
    /// </remarks>
    //template<class T>
    //static T InitializeDisposable<T>(const Func<T> initializer);// where T : class, IDisposable
    //{
    //    T item = null;
    //    T tempItem = null;
    //    try {
    //        tempItem = initializer();
    //        item = tempItem;
    //        tempItem = null;
    //    }
    //    finally { if (tempItem != null) tempItem.Dispose(); }
    //    return item;
    //}

    /// <summary>Returns true exactly if lower &lt;= value &lt; lower+height</summary>
    /// <param name="value">Vlaue being tested.</param>
    /// <param name="lower">Inclusive lower bound for the range.</param>
    /// <param name="height">Height of the range.</param>
    static bool InRange(const int value, int lower, int height);

    /// <summary>The <i>Manhattan</i> distance from this hex to that at <c>coords</c>.</summary>
    static int Range(IHex& local, IHex& target);

};


