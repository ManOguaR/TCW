// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 

#pragma once

#include "CoreMinimal.h"
#include "IntVector2D.h"
#include "HexCoords.h"

/**
 *
 */
class HEXTOOLS_API CustomCoords
{
public:
	/// <summary>Return the coordinate vector of this hex in the Custom frame.</summary>
	IntVector2D UserToCustom(HexCoords coords);
	/// <summary>Return the coordinate vector of this hex in the User frame.</summary>
	HexCoords CustomToUser(IntVector2D coords);

public:
	/// <summary>Initialize the conversion matrices for the Custom coordinate frame.</summary>
	CustomCoords(IntMatrix2D matrix);
	/// <summary>Initialize the conversion matrices for the Custom coordinate frame.</summary>
	CustomCoords(IntMatrix2D userToCustom, IntMatrix2D customToUser);
	~CustomCoords();

public:
	/// <summary>Gets the conversion @this from Custom to Rectangular (User) coordinates.</summary>
	const IntMatrix2D MatrixCustomToUser;
	/// <summary>Gets the conversion @this from Rectangular (User) to Custom coordinates.</summary>
	const IntMatrix2D MatrixUserToCustom;

	//TODO: Format Provider
	// ICustomFormatter GetFormat(Type formatType)
	//= > formatType == typeof(HexCoords) ? this : CultureInfo.CurrentUICulture.GetFormat(formatType) as ICustomFormatter;

	//TODO: Format Provider
    // string Format(string format, HexCoords coords, IFormatProvider formatProvider) {
	// if (format == null || format.Length == 0) format = "U";
	//		switch (format[0]) {
	//			case 'U': return UserToCustom(coords).ToString(format.Substring(1), formatProvider);
	//			case 'u': return "Custom: " +
	//					UserToCustom(coords).ToString(format.Substring(1), formatProvider);
	//			default:  return coords.ToString(format, formatProvider);
	//		}
	//}

	//TODO: Format Provider
	//    object IFormatProvider.GetFormat(Type formatType) = > GetFormat(formatType);
	//    string ICustomFormatter.Format(string format, object arg, IFormatProvider formatProvider)
	//        = > Format(format, arg as HexCoords ? , formatProvider);
	//    string Format(string format, HexCoords ? coords, IFormatProvider formatProvider)
	//        = > coords.HasValue ? Format(format, coords.Value, formatProvider)
	//        : HandleOtherFormats(format, coords);
	//    private static string HandleOtherFormats(string format, object obj)
	//        = > (obj is IFormattable f) ? f.ToString(format, CultureInfo.CurrentCulture)
	//        : obj ? .ToString() ? ? string.Empty;
};
