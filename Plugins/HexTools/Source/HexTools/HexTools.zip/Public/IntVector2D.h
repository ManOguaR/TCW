// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 

#pragma once

#include "CoreMinimal.h"

/**
 *
 */
class HEXTOOLS_API IntVector2D
{
#pragma region Constructors
public:
	/// <summary>Construct a new instance at offset (x,y) from the origin with norm of 1.</summary>
	/// <param name="x">The horizontal coordinate of the offset for this displacement.</param>
	/// <param name="y">The vertical coordinate of the offset for this displacement.</param>
	IntVector2D(int x, int y);
	/// <summary>Construct a new instance at offset (x,y) from the origin with norm <paramref name="norm"/>.</summary>
	/// <param name="x">The horizontal coordinate of the offset for this displacement.</param>
	/// <param name="y">The vertical coordinate of the offset for this displacement.</param>
	/// <param name="norm">The 'norm' of this augmented affine vector.</param>
	IntVector2D(int x, int y, int norm);
	~IntVector2D();
#pragma endregion

private:
	int  _x, _y, _w;

#pragma region Properties
public:
	/// <summary>The horizontal component of the vector..</summary>
	int GetX() { return _x; };
	/// <summary>The vertical component of the vector..</summary>
	int GetY() { return _y; };
	/// <summary>Get the w-component (ie scale factor or norm) of the vector.</summary>
	int GetW() { return _w; };
#pragma endregion

public:
	/// <summary>Returns a new instance with coordinates normalized using integer arithmetic.</summary>
	IntVector2D Normalize();

#pragma region Scalar operators
public:
	/// <summary>Scalar Multiplication into a new IntegerVector2D.</summary>
	static IntVector2D Multiply(int s, IntVector2D v);
	/// <summary>Scalar Multiplication into a new IntegerVector2D.</summary>
	static IntVector2D Multiply(IntVector2D v, int s);

	/// <summary>Scalar Division into a new IntegerVector2D.</summary>
	static IntVector2D Divide(IntVector2D v, int s);

private:
	static IntVector2D DivideInner(IntVector2D v, int s);
#pragma endregion

#pragma region Vector operators
public:
	/// <summary>Vector Addition of two <code>IntVector2D</code> as a new <code>IntVector2D</code>.</summary>
	static IntVector2D Add(IntVector2D v1, IntVector2D v2);
	/// <summary>Vector Subtraction of two <code>IntVector2D</code> as a new <code>IntVector2D</code></summary>
	static IntVector2D Subtract(IntVector2D v1, IntVector2D v2);

	/// <summary>Returns the vector cross-product of v1 and v2.</summary>
	static int CrossProduct(IntVector2D v1, IntVector2D v2);

	/// <summary>Returns the inner- / scalar / dot-product of v1 and v2.</summary>
	static int InnerProduct(IntVector2D v1, IntVector2D v2);

	/// <summary>Obsolete - use InnerProduct operator instead.</summary>
	static int Xor(IntVector2D v1, IntVector2D v2) { return InnerProduct(v1, v2); };
#pragma endregion


#pragma region Casts
	//		/// <summary>Returns a new instance initialized from point.</summary>
	//		public static implicit operator IntVector2D(HexPoint point)
	//		= > new IntVector2D(point.X, point.Y);
	//
	//	/// <summary>Returns a new instance initialized from size.</summary>
	//	public static implicit operator IntVector2D (HexSize size)
	//		= > new IntVector2D(size.Width, size.Height);
	//
	//	/// <summary>Returns a new Point instance initialized from vector.</summary>
	//	public static implicit operator HexPoint (IntVector2D vector)
	//		= > new HexPoint(vector.X, vector.Y);
	//
	//	/// <summary>Returns a new Size instance initialized from vector.</summary>
	//	public static implicit operator HexSize (IntVector2D vector)
	//		= > new HexSize(vector.X, vector.Y);
#pragma endregion

#pragma region Value Equality
public:
	/// <inheritdoc/>
	bool Equals(IntVector2D other);
#pragma endregion
};

#pragma region Scalar operators
/// <summary>Scalar Multiplication into a new IntegerVector2D.</summary>
static IntVector2D operator *(int s, IntVector2D v);
/// <summary>Scalar Multiplication into a new IntegerVector2D.</summary>
static IntVector2D operator *(IntVector2D v, int s);

/// <summary>Scalar Division into a new IntegerVector2D.</summary>
static IntVector2D operator /(IntVector2D v, int s);
#pragma endregion

#pragma region Vector operators
/// <summary>Scalar (Inner, or Dot) Product of two <code>IntVector2D</code> as an Int32.</summary>
static int operator * (IntVector2D v1, IntVector2D v2);
/// <summary>Z component of the 'Vector'- or Cross-Product of two <code>IntVector2D</code>s</summary>
/// <returns>A pseudo-scalar (it reverses sign on exchange of its arguments).</returns>
static int operator ^(IntVector2D v1, IntVector2D v2);

/// <summary>Vector Addition of two <code>IntVector2D</code> as a new <code>IntVector2D</code>.</summary>
static IntVector2D operator +(IntVector2D v1, IntVector2D v2);
/// <summary>Vector Subtraction of two <code>IntVector2D</code> as a new <code>IntVector2D</code></summary>
static IntVector2D operator -(IntVector2D v1, IntVector2D v2);
#pragma endregion

#pragma region Value Equality
/// <summary>Tests value-inequality.</summary>
static bool operator !=(IntVector2D lhs, IntVector2D rhs);
/// <summary>Tests value-equality.</summary>
static bool operator ==(IntVector2D lhs, IntVector2D rhs);
#pragma endregion
