// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 

#pragma once

#include "CoreMinimal.h"

/// <summary>Bit-flags for combinations of the six hexagonal directions.</summary>
enum HEXTOOLS_API Hexsides : uint8 {
	/// <summary>The selection of no hexsides.</summary>
	None = 0x00,
	/// <summary>The hexside on the top of the hex.</summary>
	North = 1 << 0,
	/// <summary>The hexside on the upper-right of the hex.</summary>
	Northeast = 1 << 1,
	/// <summary>The hexside on the lower-right of the hex</summary>
	Southeast = 1 << 2,
	/// <summary>The hexside on the bottom of the hex.</summary>
	South = 1 << 3,
	/// <summary>The hexside on the lower-left of the hex.</summary>
	Southwest = 1 << 4,
	/// <summary>The hexside on the upper-left of the hex.</summary>
	Northwest = 1 << 5,
	/// <summary>SHorthand for all hexsides.</summary>
	All = North | Northeast | Southeast | South | Southwest | Northwest
};

inline Hexsides operator|(Hexsides a, Hexsides b)
{
	return static_cast<Hexsides>(static_cast<uint8>(a) | static_cast<uint8>(b));
};
