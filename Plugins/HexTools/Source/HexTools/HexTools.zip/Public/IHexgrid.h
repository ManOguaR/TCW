// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 

#pragma once

#include "CoreMinimal.h"

/**
 *
 */
class HEXTOOLS_API IHexgrid
{
public:
	/// <summary>TODO</summary>
	virtual FVector2D GetGridSize() = 0;
	/// <summary>TODO</summary>
	virtual TArray<FIntPoint> GetHexCorners() = 0;
	/// <summary>TODO</summary>
	virtual bool GetIsTransposed() = 0;
	/// <summary>Offset of grid origin, from control's client-area origin.</summary>
	virtual FVector2D GetMargin() = 0;
	virtual void SetMargin(FVector2D value) = 0;
	/// <summary>TODO</summary>
	virtual float GetScale() = 0;
};
