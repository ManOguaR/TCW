// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 

#pragma once

#include "CoreMinimal.h"
#include "Hexside.h"
#include "IntMatrix2D.h"
#include "IntVector2D.h"

/// <summary>Coordinate structure for hexagonal grids that abstracts the distinction 
/// between rectangular (User) and canonical (Canon) bases (basis vectors, or reference 
/// frame).</summary>
/// <remarks>
/// An obtuse reference frmae, with basis vectors at 120 degrees, eases most grid 
/// calculations and movement operations; a rectangular reference frmae is easier for 
/// most user interactions, and optimal for board storage. This structure hides the
/// distinction betwene them, and automatically converting from one to the other on 
/// demand (and caching the result).
/// </remarks>
class HEXTOOLS_API HexCoords
{
#pragma region private static fields
private:
	static const IntMatrix2D _matrixUserToCanon;
	static const IntMatrix2D _matrixCanonToUser;

	static const TArray<IntVector2D> _hexsideVectorsCanon;
	static const TArray<TArray<IntVector2D>> _hexsideVectorsUser;
#pragma endregion

#pragma region public static members
public:
	/// <summary>Create a new instance located at the specified i and j offsets as interpreted in the Canon(ical) frame.</summary>
	static HexCoords NewCanonCoords(int x, int y);
	/// <summary>Create a new instance located at the specified i and j offsets as interpreted in the ectangular (User) frame.</summary>
	static HexCoords NewUserCoords(int x, int y);

	/// <summary>Create a new instance located at the specified vector offset as interpreted in the Canon(ical) frame.</summary>
	static HexCoords NewCanonCoords(IntVector2D vector);
	/// <summary>Create a new instance located at the specified vector offset as interpreted in the Rectangular (User) frame.</summary>
	static HexCoords NewUserCoords(IntVector2D vector);

	/// <summary>Origin of the Canon(ical) coordinate frame.</summary>
	static HexCoords GetEmptyCanon() { return NewCanonCoords(0, 0); };
	/// <summary>Origin of the Rectangular (User) coordinate frame.</summary>
	static HexCoords GetEmptyUser() { return NewUserCoords(0, 0); };

	/// <summary>Returns the drawing origin (upper-left) for the hex with specified user components.</summary>
	static FIntPoint HexOrigin(FVector2D gridSize, int i, int j);
#pragma endregion

#pragma region Constructors
private:
	HexCoords(IntVector2D canon, IntVector2D user);
public:
	~HexCoords();
#pragma endregion

#pragma region Properties
private:
	IntVector2D _canon, _user;
public:
	/// <summary>Returns an <c>IntVector2D</c> representing the Canonical (obtuse) coordinates of this hex.</summary>
	IntVector2D GetCanon() { return _canon; }
	/// <summary>Returns an <c>IntVector2D</c> representing the User (rectangular) coordinates of this hex.</summary>
	IntVector2D GetUser() { return _user; }

	/// <summary>Modified <i>Manhattan</i> distance of supplied coordinate from the origin.</summary>
	int RangeFromOrigin() { return GetEmptyCanon().Range(HexCoords(_canon, _user)); };
#pragma endregion

#pragma region Methods
public:
	/// <summary>Returns an <c>HexCoords</c> for the hex in direction <c>hexside</c> from this one.</summary>
	HexCoords GetNeighbour(Hexside hexside);

	/// <summary>Returns the drawing origin (upper-left) for the specified hex.</summary>
	FIntPoint HexOrigin(FVector2D gridSize);

	/// <summary>Modified <i>Manhattan</i> distance of supplied coordinate from this one.</summary>
	int Range(HexCoords coords);
#pragma endregion

#pragma region Operators
	/// <summary>(Canonical) vector sum lhs + rhs.</summary>
	/// <param name="lhs">The first term of the sum.</param>
	/// <param name="rhs">The second term of the sum.</param>
	/// <returns>A new HexCoords struct containing the vector sum lhs + rhs calculated 
	/// in the Canonical frame of reference.</returns>
	static HexCoords Add(HexCoords lhs, HexCoords rhs);
	/// <summary>(Canonical) vector difference lhs - rhs.</summary>
	/// <param name="lhs">The first term of the difference.</param>
	/// <param name="rhs">The second term of the difference.</param>
	/// <returns>A new HexCoords struct containing the vector difference lhs - rhs calculated 
	/// in the Canonical frame of reference.</returns>
	static HexCoords Subtract(HexCoords lhs, HexCoords rhs);

	/// <summary>Returns an <c>IntVector2D</c> representing the Canonical (obtuse) coordinates of <c>this</c>.</summary>
	IntVector2D ToIntVector2D();
#pragma endregion

#pragma region Value Equality
public:
	/// <inheritdoc/>
	bool Equals(HexCoords other);
#pragma endregion
};

#pragma region Operators
/// <summary>Vector sum; <see cref="Add"/>.</summary>
static HexCoords operator + (HexCoords lhs, HexCoords rhs);
/// <summary>Vector difference; <see cref="Subtract"/>.</summary>
static HexCoords operator - (HexCoords lhs, HexCoords rhs);
#pragma endregion

#pragma region Value Equality Operators
/// <summary>Tests value-inequality.</summary>
static bool operator != (HexCoords lhs, HexCoords rhs);
/// <summary>Tests value-equality.</summary>
static bool operator == (HexCoords lhs, HexCoords rhs);
#pragma endregion




//TODO: TO STRING

///// <summary>Culture-invariant string representation of this instance's value.</summary>
//public override string ToString() = > ToString("g", CultureInfo.InvariantCulture);
//
///// <summary>Converts the value of this instance to its equivalent string representation using the 
///// specified format and culture-specific format information.</summary>
///// <param name="format">Type: System.String. 
///// 
///// > A standard or custom numeric format string.</param>
///// <param name="formatProvider">Type: IFormatProvider - 
///// 
///// > An object that supplies culture-specific formatting information.</param>
///// <remarks>
///// Format characters:
///// - 'C' or 'c': Canonical formatting - Int2Vector output of the Canonical coordinates for this hex;
///// - 'G' or 'g': General formatting - Int2Vector output of the User coordinates for this hex;
///// - 'R' or 'r': Range formatting - Scalar output of the Range of this hex from canonical (0,0);
///// In all cases the leading character of the format string is stripped off and parsed, 
///// with the remainder passed to the formatter completing the display formatting.
///// 
///// If an instance of <see cref="CustomCoords"/> is passed as the <see cref="IFormatProvider"/> then
///// two additional formats are supported:
///// - 'U' or 'u': Custom formatting - Int2Vector output of the Custom coordinates for this hex.
///// 
///// Likewise, any additional formats supported by <paramref name="formatProvider"/> can be processed.
///// 
///// The lower-case format comands prefix a descriptive string on the output (ie one of "Canon: ",
///// "User: ", "Custom: ", or "Range: " respectivelly), while the upper-case commands do not.
///// </remarks>
//public string ToString(string format, IFormatProvider formatProvider) {
//
//	if (format == null || format.Length == 0) format = "G";
//	if (formatProvider == null) formatProvider = CultureInfo.CurrentUICulture;
//	switch (format[0]) {
//	case 'C':
//	case 'G':
//	case 'R': return Format(format[0], format.Substring(1), formatProvider);
//	case 'c': return "Canon: " + Format(format[0], format.Substring(1), formatProvider);
//	case 'g': return "User: " + Format(format[0], format.Substring(1), formatProvider);
//	case 'r': return "Range: " + Format(format[0], format.Substring(1), formatProvider);
//
//	default:  var formatter = formatProvider.GetFormat(typeof(HexCoords)) as ICustomFormatter
//		? ? formatProvider.GetFormat(typeof(object)) as ICustomFormatter;
//		if (formatter == null) return string.Empty;
//		return formatter.Format(format, this, formatProvider) ? ? string.Empty;
//	}
//}
//
//private string Format(char formatChar, string formatRest, IFormatProvider formatProvider) {
//	switch (formatChar) {
//	case 'c':
//	case 'C': return Canon.ToString(formatRest, formatProvider);
//	case 'g':
//	case 'G': return User.ToString(formatRest, formatProvider);
//	case 'r':
//	case 'R': return Range(HexCoords.EmptyCanon).ToString("G" + formatRest, formatProvider);
//	default:  return string.Empty;
//	}
//}

