// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 

#pragma once

#include "CoreMinimal.h"

#include "Hexsides.h"

/**
 *
 */
class HEXTOOLS_API Hexside
{
#pragma region Enum Constants
public:
	/// <summary>The hexside on the top of the hex.</summary>
	static const Hexside North;
	/// <summary>The hexside on the upper-right of the hex.</summary>
	static const Hexside Northeast;
	/// <summary>The hexside on the lower-right of the hex</summary>
	static const Hexside Southeast;
	/// <summary>The hexside on the bottom of the hex.</summary>
	static const Hexside South;
	/// <summary>The hexside on the lower-left of the hex.</summary>
	static const Hexside Southwest;
	/// <summary>The hexside on the upper-left of the hex.</summary>
	static const Hexside Northwest;
#pragma endregion

#pragma region Constructor
private:
	Hexside(int value, FString name, Hexsides hexsides);
#pragma endregion

public:
	~Hexside();

#pragma region Static members
public:
	/// <summary><c>Static List {Hexside}</c> for enumerations.</summary>
	static const TArray<Hexside> HexsideList;
	//{ get; } = new Hexside[]{North,Northeast,Southeast,South,Southwest,Northwest }.ToFastList();

	//TODO: FOREACH
	/// <summary>Performs <c>action</c> for each Enum value of <c>Hexside</c>.</summary>
	/// <param name="action"></param>
	//static void ForEach(Action<Hexside> action) = > HexsideList.ForEach(action);

	//TODO: FOREACH
	/// <summary>Perform the Invoke() method of <c>functor</c> for each value of Enum <c>Hexside</c>.</summary>
	/// <param name="functor"></param>
	//static void ForEach(FastIteratorFunctor<Hexside> functor) = > HexsideList.ForEach(functor);

	//TODO: ParseEnum
	/// <summary>Returns the <see cref="Hexside"/> with this <paramref name="name"/>.</summary>
	/// <param name="name">The <see cref="Hexside"/> string to be parsed and recognized.</param>
	/// <param name="ignoreCase">Specifies whether or not a case-insensitive parse is desired.</param>
	//static Hexside ParseEnum(string name, bool ignoreCase) {
	//	var index = ignoreCase ? _namesUncased.IndexOf(name.ToUpper(CultureInfo.InvariantCulture))
	//		: _namesCased.IndexOf(name);
	//	if (index == -1) throw new ArgumentOutOfRangeException("name", name, "Enum type: " + typeof(Hexside).Name);
	//	return HexsideList[index];;
	//}

	/// <summary>Returns the single <see cref="Hexsides"/> value corresponding to this <paramref name="hexside"/>.</summary>
	/// <param name="hexside">The supplied <see cref="Hexside"/>.</param>
	static Hexsides ToHexsides(Hexside hexside) { return hexside.GetAsHexsides(); };

	/// <summary>Enables implicit casting of a <see cref="Hexside"/> as a <see cref="int"/>.</summary>
	/// <param name="hexside">The supplied <see cref="Hexside"/>.</param>
	static int ToInt(Hexside hexside) { return hexside.GetValue(); };

private:
	//TODO: Names Cased and Uncased
	//static readonly IList<string> _namesCased = (from hexside in HexsideList select hexside.Name).ToList();
	//static readonly IList<string> _namesUncased = (from name in _namesCased select name.ToUpper(CultureInfo.InvariantCulture)).ToList();
#pragma endregion

#pragma region  Instance members
private:
	Hexsides _asHexsides;
	FString _name;
	int _value;
	const int _reversed;
public:
	/// <summary>The <c>Hexsides</c> bit corresponding to this <c>Hexside</c>.</summary>
	Hexsides GetAsHexsides() { return _asHexsides; };

	/// <summary>The name of this enumeration constant.</summary>
	FString GetName() { return _name; };

	/// <summary>Returns the reversed, or opposite, <see cref="Hexside"/> to this one.</summary>
	Hexside GetReversed() { return HexsideList[_reversed]; };

	/// <summary>The integer value for this enumeration constant.</summary>
	int GetValue() { return _value; };

	/// <inheritdoc/>
	FString ToString() { return _name; };
#pragma endregion

};
