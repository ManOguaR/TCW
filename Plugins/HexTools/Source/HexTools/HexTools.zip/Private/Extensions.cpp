// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 


#include "Extensions.h"

int Extensions::Modulo(const int dividend, int divisor)
{
	int divd = dividend;
	while (divd < 0)
		divd += divisor;
	while (divd > divisor)
		divd -= divisor;
	return divd;
}

bool Extensions::IsOnboard(const FVector2D mapSizeHexes, HexCoords hexCoords)
{
	return Extensions::IsOnboard(mapSizeHexes, hexCoords.GetUser());;
}

bool Extensions::IsOnboard(const FVector2D mapSizeHexes, IntVector2D userCoords)
{
	return Extensions::IsOnboard(mapSizeHexes, userCoords.GetX(), userCoords.GetY());
}

bool Extensions::IsOnboard(const FVector2D mapSizeHexes, int x, int y)
{
	return Extensions::InRange(x, 0, mapSizeHexes.X) && Extensions::InRange(y, 0, mapSizeHexes.Y);
}

bool Extensions::InRange(const int value, int lower, int height)
{
	return lower <= value && value < lower + height;
}

int Extensions::Range(IHex& local, IHex& target)
{
	return local.GetCoords().Range(target.GetCoords());
}
