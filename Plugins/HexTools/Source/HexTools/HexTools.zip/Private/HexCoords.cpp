// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 

#include "HexCoords.h"

const IntMatrix2D HexCoords::_matrixUserToCanon = IntMatrix2D(2, 1, 0, 2, 0, 0, 2);
const IntMatrix2D HexCoords::_matrixCanonToUser = IntMatrix2D(2, -1, 0, 2, 0, 1, 2);

const TArray<IntVector2D> HexCoords::_hexsideVectorsCanon = {
	IntVector2D(0, -1),		// HexSide.North
	IntVector2D(1, 0),		// HexSide.NorthEast
	IntVector2D(1, 1),		// HexSide.SouthEast
	IntVector2D(0, 1),		// HexSide.South
	IntVector2D(-1, 0),		// HexSide.SouthWest
	IntVector2D(-1, -1)		// HexSide.NorthWest
};

const TArray<TArray<IntVector2D>> HexCoords::_hexsideVectorsUser = {
	{
		IntVector2D(0, -1),		// even x HexSide.North
		IntVector2D(1, 0),		// even x HexSide.NorthEast
		IntVector2D(1, 1),		// even x HexSide.SouthEast
		IntVector2D(0, 1),		// even x HexSide.South
		IntVector2D(-1, 1),		// even x HexSide.SouthWest
		IntVector2D(-1, 0)		// even x HexSide.NorthWest
	},{
		IntVector2D(0, -1),		// odd x HexSide.North
		IntVector2D(1, -1),		// odd x HexSide.NorthEast
		IntVector2D(1, 0),		// odd x HexSide.SouthEast
		IntVector2D(0, 1),		// odd x HexSide.South
		IntVector2D(-1, 0),		// odd x HexSide.South West
		IntVector2D(-1, -1)		// odd x HexSide.NorthWest
	}
};

HexCoords HexCoords::NewCanonCoords(int x, int y)
{
	return NewCanonCoords(IntVector2D(x, y));
}
HexCoords HexCoords::NewUserCoords(int x, int y)
{
	return NewUserCoords(IntVector2D(x, y));
}

HexCoords HexCoords::NewCanonCoords(IntVector2D vector)
{
	return HexCoords(vector, vector * _matrixCanonToUser);
}
HexCoords HexCoords::NewUserCoords(IntVector2D vector)
{
	return HexCoords(vector * _matrixUserToCanon, vector);
}

FIntPoint HexCoords::HexOrigin(FVector2D gridSize, int i, int j)
{
	return FIntPoint((i * gridSize.X), (j * gridSize.Y + (i + 1) % 2 * (gridSize.Y) / 2));
}

HexCoords::HexCoords(IntVector2D canon, IntVector2D user) :
	_canon(canon),
	_user(user)
{}

HexCoords::~HexCoords()
{
}

HexCoords HexCoords::GetNeighbour(Hexside hexside)
{
	int i = _user.GetX() & 1;
	return HexCoords(_canon + _hexsideVectorsCanon[Hexside::ToInt(hexside)], _user + _hexsideVectorsUser[i][Hexside::ToInt(hexside)]);
}

FIntPoint HexCoords::HexOrigin(FVector2D gridSize)
{
	return HexOrigin(gridSize, _user.GetX(), _user.GetY());
}

int HexCoords::Range(HexCoords coords)
{
	int deltaX = coords._canon.GetX() - _canon.GetX();
	int deltaY = coords._canon.GetY() - _canon.GetY();
	return (FMath::Abs(deltaX) + FMath::Abs(deltaY) + FMath::Abs(deltaX - deltaY)) / 2;
}

HexCoords HexCoords::Add(HexCoords lhs, HexCoords rhs)
{
	return lhs + rhs;
}

HexCoords HexCoords::Subtract(HexCoords lhs, HexCoords rhs)
{
	return lhs - rhs;
}

IntVector2D HexCoords::ToIntVector2D()
{
	return _canon;
}

bool HexCoords::Equals(HexCoords other)
{
	return _user == other._user;
}

HexCoords operator+(HexCoords lhs, HexCoords rhs)
{
	return HexCoords::NewCanonCoords(lhs.GetCanon() + rhs.GetCanon());
}

HexCoords operator-(HexCoords lhs, HexCoords rhs)
{
	return HexCoords::NewCanonCoords(lhs.GetCanon() - rhs.GetCanon());
}

bool operator!=(HexCoords lhs, HexCoords rhs)
{
	return !(lhs.Equals(rhs));
}

bool operator==(HexCoords lhs, HexCoords rhs)
{
	return lhs.Equals(rhs);
}

