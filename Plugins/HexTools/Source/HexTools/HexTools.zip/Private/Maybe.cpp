// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 


#include "Maybe.h"

template<class T>
Maybe<T> Maybe<T>::NoValue()
{
	return Maybe<T>();
}

template<class T>
Maybe<T>::Maybe() {}

template<class T>
Maybe<T>::Maybe(T value) :
	Value(value)
{
}

template<class T>
Maybe<T>::~Maybe() {}

//template<class T>
//bool Maybe<T>::ValueContract(Func<T, bool> contract)
//{
//	return !HasValue || contract(Value);
//}

template<class T>
FString Maybe<T>::PreferredName(T value)
{
	return value.ToString();
}

template<class T>
FString Maybe<T>::AlternateName()
{
	return "NoValue<" + typeof(T).Name + ">";
}

template<class T>
Maybe<T> Maybe<T>::From(T value)
{
	return Maybe<T>(value);
}

template<class T>
bool Maybe<T>::Equals(Maybe<T> other)
{
	return (HasValue && other.HasValue && Value.Equals(other.Value)) || (!HasValue && !other.HasValue);
}

template<class T>
FString Maybe<T>::ToString()
{
	return (HasValue && Value != null) ? PreferredName(Value) : AlternateName();
}

//template<class T>
//template<class TOut>
//inline Maybe<TOut> Maybe<T>::Bind(Func<T, Maybe<TOut>> projection)
//{
//	return HasValue ? projection(Value) : Maybe<TOut>.NoValue();
//}

//template<class T>
//template<class TOut>
//TOut Maybe<T>::Match(Func<T, TOut> projection, Func<TOut> alternate)
//{
//	return HasValue ? projection(Value) : alternate();
//}

//template<class T>
//Maybe<V> Maybe<T>::ToMaybe(Maybe<V> maybe)
//{
//	return !maybe.HasValue || !maybe.Value.HasValue ? Maybe<V>.NoValue() : maybe.Value.Value;
//}
//
//template<class T>
//V Maybe<T>::ToNullable(Maybe<V> maybe)
//{
//	return !maybe.HasValue || !maybe.Value.HasValue ? (V ? )null : maybe.Value.Value;
//}
