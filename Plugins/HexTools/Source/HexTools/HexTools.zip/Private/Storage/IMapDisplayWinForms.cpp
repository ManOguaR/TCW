// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 


#include "IMapDisplayWinForms.h"

IMapDisplayWinForms::IMapDisplayWinForms()
{
}

IMapDisplayWinForms::~IMapDisplayWinForms()
{
}
