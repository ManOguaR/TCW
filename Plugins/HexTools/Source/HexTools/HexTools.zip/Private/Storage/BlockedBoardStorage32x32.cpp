// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 


#include "BlockedBoardStorage32x32.h"

BlockedBoardStorage32x32::BlockedBoardStorage32x32()
{
}

BlockedBoardStorage32x32::~BlockedBoardStorage32x32()
{
}
