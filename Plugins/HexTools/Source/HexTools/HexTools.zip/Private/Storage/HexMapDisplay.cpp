// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 


#include "HexMapDisplay.h"

HexMapDisplay::HexMapDisplay()
{
}

HexMapDisplay::~HexMapDisplay()
{
}
