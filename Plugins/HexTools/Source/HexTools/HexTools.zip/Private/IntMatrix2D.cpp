// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 


#include "IntMatrix2D.h"

IntMatrix2D::IntMatrix2D(IntVector2D vector) :
	IntMatrix2D(1, 0, 0, 1, vector.GetX(), vector.GetY(), 1) {}
IntMatrix2D::IntMatrix2D(int dx, int dy) :
	IntMatrix2D(1, 0, 0, 1, dx, dy, 1) {}
IntMatrix2D::IntMatrix2D(int m11, int m12, int m21, int m22) :
	IntMatrix2D(m11, m12, m21, m22, 0, 0, 1) {}
IntMatrix2D::IntMatrix2D(int m11, int m12, int m21, int m22, int dx, int dy) :
	IntMatrix2D(m11, m12, m21, m22, dx, dy, 1) {}

IntMatrix2D::IntMatrix2D(int m11, int m12, int m21, int m22, int dx, int dy, int norm) :
	_m11(m11), _m12(m12), _m21(m21), _m22(m22), _m31(dx), _m32(dy), _m33(norm)
{
	//	if (norm == 0) throw new ArgumentNullException(nameof(norm));
}

IntMatrix2D::~IntMatrix2D()
{
}

IntVector2D IntMatrix2D::Multiply(IntVector2D v, IntMatrix2D m)
{
	return IntVector2D(
		v.GetX() * m._m11 + v.GetY() * m._m21 + m._m31,
		v.GetX() * m._m12 + v.GetY() * m._m22 + m._m32,
		v.GetW() * m._m33
		).Normalize();
}
IntVector2D IntMatrix2D::Multiply(IntMatrix2D m, IntVector2D v)
{
	return IntVector2D(
		v.GetX() * m._m11 + v.GetY() * m._m12 + m._m31,
		v.GetX() * m._m21 + v.GetY() * m._m22 + m._m32,
		v.GetW() * m._m33
		).Normalize();
}

IntMatrix2D IntMatrix2D::Multiply(IntMatrix2D m1, IntMatrix2D m2)
{
	return  IntMatrix2D(
		m1._m11 * m2._m11 + m1._m12 * m2._m21, m1._m11 * m2._m12 + m1._m12 * m2._m22,
		m1._m21 * m2._m11 + m1._m22 * m2._m21, m1._m21 * m2._m12 + m1._m22 * m2._m22,
		m1._m31 * m2._m11 + m1._m32 * m2._m21 + m2._m31, m1._m31 * m2._m12 + m1._m32 * m2._m22 + m2._m32, m1._m33 * m2._m33
		);
}

const IntMatrix2D IntMatrix2D::Identity = IntMatrix2D(1, 0, 0, 1, 0, 0, 1);

IntVector2D operator*(IntVector2D v, IntMatrix2D m)
{
	return IntMatrix2D::Multiply(v, m);
}

IntVector2D operator*(IntMatrix2D m, IntVector2D v)
{
	return IntMatrix2D::Multiply(m, v);
}

IntMatrix2D operator*(IntMatrix2D m1, IntMatrix2D m2)
{
	return IntMatrix2D::Multiply(m1, m2);
}
