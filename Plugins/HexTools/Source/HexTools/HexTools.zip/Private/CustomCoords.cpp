// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 


#include "CustomCoords.h"

IntVector2D CustomCoords::UserToCustom(HexCoords coords)
{
	return coords.GetUser() * MatrixUserToCustom;
}

HexCoords CustomCoords::CustomToUser(IntVector2D coords)
{
	return HexCoords::NewUserCoords(coords * MatrixUserToCustom);
}

CustomCoords::CustomCoords(IntMatrix2D matrix) :CustomCoords(matrix, matrix) {}

CustomCoords::CustomCoords(IntMatrix2D userToCustom, IntMatrix2D customToUser) :
	MatrixCustomToUser(customToUser),
	MatrixUserToCustom(userToCustom)
{}

CustomCoords::~CustomCoords() {}
