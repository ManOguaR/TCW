// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 


#include "Hex.h"

Hex::Hex(HexCoords coords) : Hex(coords, 0) {}

Hex::Hex(HexCoords coords, int elevationLevel) :
	Coords(coords),
	ElevationLevel(elevationLevel) {}

Hex::~Hex() {}

HexCoords Hex::GetCoords() { return Coords; }

int Hex::GetElevationLevel() { return ElevationLevel; }

int Hex::GetHeightObserver() { return HeightObserver; }

int Hex::GetHeightTarget() { return HeightTarget; }

int Hex::GetHeightHexside(Hexside hexside) { return GetHeightTerrain(); }

bool Hex::Equals(Hex& other)
{
	return Coords == other.Coords;
}

bool operator!=(Hex& lhs, Hex& rhs)
{
	return !lhs.Equals(rhs);
}

bool operator==(Hex& lhs, Hex& rhs)
{
	return lhs.Equals(rhs);
}
