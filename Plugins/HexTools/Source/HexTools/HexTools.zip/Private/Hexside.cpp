// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 

#include "Hexside.h"

const Hexside Hexside::North = Hexside(0, TEXT("North"), Hexsides::North);
const Hexside Hexside::Northeast = Hexside(1, "Northeast", Hexsides::Northeast);
const Hexside Hexside::Southeast = Hexside(2, "Southeast", Hexsides::Southeast);
const Hexside Hexside::South = Hexside(3, "South", Hexsides::South);
const Hexside Hexside::Southwest = Hexside(4, "Southwest", Hexsides::Southwest);
const Hexside Hexside::Northwest = Hexside(5, "Northwest", Hexsides::Northwest);

Hexside::Hexside(int value, FString name, Hexsides hexsides) :
	_asHexsides(hexsides),
	_name(name),
	_value(value),
	_reversed((value + 3) % 6)
{}

Hexside::~Hexside() {}

const TArray<Hexside> Hexside::HexsideList = { North, Northeast, Southeast, South, Southwest, Northwest };
