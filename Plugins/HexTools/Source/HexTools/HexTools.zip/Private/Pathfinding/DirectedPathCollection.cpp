// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 


#include "DirectedPathCollection.h"

DirectedPathCollection::DirectedPathCollection()
{
}

DirectedPathCollection::~DirectedPathCollection()
{
}
