// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 


#include "PriorityQueueFactory.h"

PriorityQueueFactory::PriorityQueueFactory()
{
}

PriorityQueueFactory::~PriorityQueueFactory()
{
}
