// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 


#include "HexKeyValuePair.h"

HexKeyValuePair::HexKeyValuePair()
{
}

HexKeyValuePair::~HexKeyValuePair()
{
}
