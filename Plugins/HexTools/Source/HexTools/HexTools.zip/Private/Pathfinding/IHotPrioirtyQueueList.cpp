// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 


#include "IHotPrioirtyQueueList.h"

IHotPrioirtyQueueList::IHotPrioirtyQueueList()
{
}

IHotPrioirtyQueueList::~IHotPrioirtyQueueList()
{
}
