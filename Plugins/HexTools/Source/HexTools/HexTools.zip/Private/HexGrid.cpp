// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 


#include "HexGrid.h"

HexGrid::HexGrid(bool isTransposed, FVector2D gridSize, float scale) : HexGrid(isTransposed, gridSize, scale, FVector2D::ZeroVector)
{
}

HexGrid::HexGrid(bool isTransposed, FVector2D gridSize, float scale, FVector2D margin):
	_gridSize(gridSize),
	_isTransposed(isTransposed),
	_margin(margin),
	_scale(scale)
{
	_hexCorners = TArray<FIntPoint>{
		FIntPoint(gridSize.X * 1 / 3, 0),
		FIntPoint(gridSize.X * 3 / 3, 0),
		FIntPoint(gridSize.X * 4 / 3, gridSize.Y / 2),
		FIntPoint(gridSize.X * 3 / 3, gridSize.Y),
		FIntPoint(gridSize.X * 1 / 3, gridSize.Y),
		FIntPoint(0, gridSize.Y / 2),
		FIntPoint(gridSize.X * 1 / 3, 0)
	};
}

HexGrid::~HexGrid()
{
}
