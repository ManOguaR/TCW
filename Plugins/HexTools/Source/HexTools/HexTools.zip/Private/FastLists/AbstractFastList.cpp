// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 


#include "AbstractFastList.h"

AbstractFastList::AbstractFastList()
{
}

AbstractFastList::~AbstractFastList()
{
}
