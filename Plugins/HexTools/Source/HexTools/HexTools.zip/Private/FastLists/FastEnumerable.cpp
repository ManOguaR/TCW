// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 


#include "FastEnumerable.h"

FastEnumerable::FastEnumerable()
{
}

FastEnumerable::~FastEnumerable()
{
}
