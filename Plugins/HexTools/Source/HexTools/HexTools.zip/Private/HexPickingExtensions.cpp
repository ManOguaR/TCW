// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 


#include "HexPickingExtensions.h"

//FIntPoint HexPickingExtensions::GetScrollPosition(IHexgrid& hexGrid, FIntPoint scrollPosition)
//{
//	return hexGrid.GetIsTransposed() ? HexPickingExtensions::TransposePoint(scrollPosition) : scrollPosition;
//}
//
//FVector2D HexPickingExtensions::GridSizeF(IHexgrid& hexGrid)
//{
//	return hexGrid.GetGridSize().Scale(hexGrid.GetScale());
//}
//
//HexCoords HexPickingExtensions::GetHexCoords(IHexgrid& hexGrid, FVector2D point, FVector2D autoScroll)
//{
//	// Adjust for origin not as assumed by GetCoordinate().
//	FVector2D grid = FVector2D(HexPickingExtensions::GridSizeF(hexGrid).X * 2.0f / 3.0f, HexPickingExtensions::GridSizeF(hexGrid).Y);
//	point -= autoScroll + grid - FVector2D(hexGrid.GetMargin().X, hexGrid.GetMargin().Y);
//
//	return HexCoords::NewCanonCoords(HexPickingExtensions::GetCoordinate(hexGrid, HexPickingExtensions::MatrixX(hexGrid), point),
//		HexPickingExtensions::GetCoordinate(hexGrid, HexPickingExtensions::MatrixY(hexGrid), point));
//}
//
//HexCoords HexPickingExtensions::GetHexCoords(IHexgrid& hexGrid, FIntPoint point, FVector2D autoScroll)
//{
//	return hexGrid.GetIsTransposed() ? HexPickingExtensions::GetHexCoordsInner(hexGrid, HexPickingExtensions::TransposePoint(point), HexPickingExtensions::TransposeSize(autoScroll)) : HexPickingExtensions::GetHexCoordsInner(hexGrid, point, autoScroll);
//}
//
//HexCoords HexPickingExtensions::GetHexCoordsInner(IHexgrid& hexGrid, FIntPoint point, FVector2D autoScroll)
//{
//	// Adjust for origin not as assumed by GetCoordinate().
//	FVector2D grid = FVector2D((int)(HexPickingExtensions::GridSizeF(hexGrid).X * 2.0f / 3.0f), (int)HexPickingExtensions::GridSizeF(hexGrid).Y);
//	point -= autoScroll + grid - hexGrid.GetMargin();
//
//	return HexCoords::NewCanonCoords(HexPickingExtensions::GetCoordinate(hexGrid, HexPickingExtensions::MatrixX(hexGrid), point),
//		HexPickingExtensions::GetCoordinate(hexGrid, HexPickingExtensions::MatrixY(hexGrid), point));
//}
//
//FIntPoint HexPickingExtensions::HexCenterPoint(IHexgrid& hexGrid, HexCoords coordsNewULHex)
//{
//	return hexGrid.GetIsTransposed() ? TransposePoint(HexPickingExtensions::HexCenterPointInner(hexGrid, coordsNewULHex)) : HexPickingExtensions::HexCenterPointInner(hexGrid, coordsNewULHex);
//}
//
//FIntPoint HexPickingExtensions::HexCenterPointInner(IHexgrid& hexGrid, HexCoords coordsNewULHex)
//{
//	return HexPickingExtensions::HexOrigin(hexGrid, coordsNewULHex) + FVector2D((int)(HexPickingExtensions::GridSizeF(hexGrid).X * 2.0f / 3.0f), (int)HexPickingExtensions::GridSizeF(hexGrid).Y);
//}
//
//FIntPoint HexPickingExtensions::HexOrigin(IHexgrid& hexGrid, HexCoords coords)
//{
//	return FIntPoint((int)(HexPickingExtensions::GridSizeF(hexGrid).X * coords.GetUser().GetX()),
//		(int)(HexPickingExtensions::GridSizeF(hexGrid).Y * coords.GetUser().GetY() + HexPickingExtensions::GridSizeF(hexGrid).Y / 2 * (coords.GetUser().X + 1) % 2));
//}
//
//int HexPickingExtensions::GetCoordinate(IHexgrid& hexGrid, FMatrix matrix, FIntPoint point)
//{
//	FIntPoint points[] = { point };
//	matrix.TransformPoints(points);
//
//	return (int)FMath::Floor((points[0].X + points[0].Y + 2.0f) / 3.0f);
//}
//
//int HexPickingExtensions::GetCoordinate(IHexgrid& hexGrid, FMatrix matrix, FVector2D point)
//{
//	FVector2D points[] = { point };
//	matrix.TransformPoints(points);
//
//	return (int)FMath::Floor((points[0].X + points[0].Y + 2.0f) / 3.0f);
//}
//
//FMatrix HexPickingExtensions::MatrixX(IHexgrid& hexGrid)
//{
//	return FMatrix(
//	(3.0F / 2.0F) / HexPickingExtensions::GridSizeF(hexGrid).X, (3.0F / 2.0F) / HexPickingExtensions::GridSizeF(hexGrid).X,
//		1.0F / HexPickingExtensions::GridSizeF(hexGrid).Y, -1.0F / HexPickingExtensions::GridSizeF(hexGrid).Y, -0.5F, -0.5F);
//}
//
//FMatrix HexPickingExtensions::MatrixY(IHexgrid& hexGrid)
//{
//	return FMatrix(
//		0.0F, (3.0F / 2.0F) / HexPickingExtensions::GridSizeF(hexGrid).X,
//		2.0F / HexPickingExtensions::GridSizeF(hexGrid).Y, 1.0F / HexPickingExtensions::GridSizeF(hexGrid).Y, -0.5F, -0.5F);
//}
//
//FIntPoint HexPickingExtensions::TransposePoint(FIntPoint point)
//{
//	return FIntPoint(point.Y, point.X);
//}
//
//FVector2D HexPickingExtensions::TransposeSize(FVector2D size)
//{
//	return FVector2D(size.Y, size.X);
//}
