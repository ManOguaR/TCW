// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 


#include "FovCone.h"

FovCone::FovCone()
{
}

FovCone::~FovCone()
{
}
