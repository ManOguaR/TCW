// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 


#include "ShadowCastingFov_Utilities.h"

ShadowCastingFov_Utilities::ShadowCastingFov_Utilities()
{
}

ShadowCastingFov_Utilities::~ShadowCastingFov_Utilities()
{
}
