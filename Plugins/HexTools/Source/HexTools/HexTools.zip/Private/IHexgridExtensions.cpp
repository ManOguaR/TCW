#include "IHexgridExtensions.h"

FIntPoint IHexgridExtensions::ScrollPositionToCenterOnHex(const IHexgrid& hexGrid, HexCoords coordsNewCenterHex, CoordsRectangle visibleRectangle)
{
	//TODO: return hexGrid.HexCenterPoint(HexCoords::NewUserCoords(coordsNewCenterHex.GetUser() - (visibleRectangle.GetSize().GetUser() / 2)));
	return FIntPoint(); //=> @this.HexCenterPoint(HexCoords.NewUserCoords(coordsNewCenterHex.User - (visibleRectangle.Size.User / 2)) );
}

FVector2D IHexgridExtensions::GetSize(const IHexgrid& hexGrid, FVector2D mapSizePixels, float mapScale)
{
	//TODO:  HexSize.Ceiling(mapSizePixels.Scale(mapScale));
	return FVector2D();	//= > HexSize.Ceiling(mapSizePixels.Scale(mapScale));
}
