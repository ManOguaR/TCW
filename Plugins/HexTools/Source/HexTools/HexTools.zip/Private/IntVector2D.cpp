// Copyrigth (c) 2020 Softwar 19.23 NGS. All rigths reserved. 


#include "IntVector2D.h"

IntVector2D::IntVector2D(int x, int y) :
	IntVector2D(x, y, 1)
{
}

IntVector2D::IntVector2D(int x, int y, int norm) :
	_x(x),
	_y(y),
	_w(norm)
{
}

IntVector2D::~IntVector2D()
{
}

IntVector2D IntVector2D::Normalize()
{
	switch (_w) {
	case 1:   return IntVector2D(_x, _y);
	case 2:   return IntVector2D(_x / 2, _y / 2);
	case 4:   return IntVector2D(_x / 4, _y / 4);
	case 8:   return IntVector2D(_x / 8, _y / 8);
		// Wow! All this because integer division wasn't defined to be a field operator.
	default:  return IntVector2D(FMath::Sign(_x) * FMath::Sign(_w) * FMath::Abs(_x) / FMath::Abs(_w),
		FMath::Sign(_y) * FMath::Sign(_w) * FMath::Abs(_y) / FMath::Abs(_w));
	}
}

IntVector2D IntVector2D::Multiply(int s, IntVector2D v)
{
	return Multiply(v, s);
}

IntVector2D IntVector2D::Multiply(IntVector2D v, int s)
{
	return IntVector2D(v._x * s, v._y * s);
}

IntVector2D IntVector2D::Divide(IntVector2D v, int s)
{
	return DivideInner(v, s);
}

IntVector2D IntVector2D::DivideInner(IntVector2D v, int s)
{
	return IntVector2D(v._x / s, v._y / s);
}

IntVector2D IntVector2D::Add(IntVector2D v1, IntVector2D v2)
{
	return IntVector2D(v1._x + v2._x, v1._y + v2._y);
}

IntVector2D IntVector2D::Subtract(IntVector2D v1, IntVector2D v2)
{
	return IntVector2D(v1._x - v2._x, v1._y - v2._y);
}

int IntVector2D::CrossProduct(IntVector2D v1, IntVector2D v2)
{
	return (v1._x * v2._y) - (v1._y * v2._x);
}

int IntVector2D::InnerProduct(IntVector2D v1, IntVector2D v2)
{
	return (v1._x * v2._x) + (v1._y * v2._y);
}

bool IntVector2D::Equals(IntVector2D other)
{
	return (other._w * _x == _w * other._x) && (other._w * _y == _w * other._y);
}

IntVector2D operator*(int s, IntVector2D v)
{
	return v * s;
}

IntVector2D operator*(IntVector2D v, int s)
{
	return IntVector2D::Multiply(v, s);
}

IntVector2D operator/(IntVector2D v, int s)
{
	return IntVector2D::Divide(v, s);
}

int operator*(IntVector2D v1, IntVector2D v2)
{
	return IntVector2D::InnerProduct(v1, v2);
}

int operator^(IntVector2D v1, IntVector2D v2)
{
	return IntVector2D::CrossProduct(v1, v2);
}

IntVector2D operator+(IntVector2D v1, IntVector2D v2)
{
	return IntVector2D::Add(v1, v2);
}

IntVector2D operator-(IntVector2D v1, IntVector2D v2)
{
	return IntVector2D::Subtract(v1, v2);
}

bool operator!=(IntVector2D lhs, IntVector2D rhs)
{
	return !lhs.Equals(rhs);
}

bool operator==(IntVector2D lhs, IntVector2D rhs)
{
	return lhs.Equals(rhs);
}
